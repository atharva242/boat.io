var PLAY = 1;
var END = 0;
var gameState = PLAY;



var line,line2;
var sea,seaImg;
var boat,boatImg;
var cloud1,cloud1Img;
var shark,sharkImg;
var sun,sunImg;
var obstacleGroup;
var p2Group;
var gameover,gameoverImg,restart,restartImg;
var coin,coinImg;

var score=0;
var points=0;

function preload(){
seaImg = loadImage("th (5).jpeg");
boatImg = loadImage("speed-boat-png-hd-jet-black-crimson-red-1440 (1).png");
 gameoverImg=loadImage("gameOver.png");
  restartImg=loadImage("restart.png")
 sharkImg=loadImage("Shark-PNG-Image.png")
  sunImg = loadImage("sun.png");
  coinImg=loadImage("coin3.png");
  
}
function setup(){
createCanvas(600,600);
  sea = createSprite(250,250,10,10);
  sea.addImage(seaImg);
  sea.scale = 5;

  sun = createSprite(400,50,101,0);
  sun.addImage(sunImg);
  sun.scale = 0.1;
  boat = createSprite(100,150,10,10);
  boat.addImage(boatImg);
  boat.scale = 0.2;
  line = createSprite(200,550,10000,5);
  line2 = createSprite(200,10,1000,5);
  
  gameover=createSprite(300,20);
  gameover.addImage(gameoverImg);
  restart=createSprite(300,70);
  restart.addImage(restartImg);
  
   obstacleGroup = new Group();
  p2Group = new Group();

}
function draw(){
  background("black");
  line.visible = false;
  boat.bounceOff(line);
  boat.bounceOff(line2);

  line2.visible = false;
  
  
  if(gameState===PLAY){
    p2();
    sea.velocityX = -5;
 if (sea.x < 0){
      sea.x = sea.width/2;
    }
 if(boat.isTouching(p2Group)){
   points=points+1
   p2Group.destroyEach();
 }
  gameover.visible=false;
    restart.visible=false;
   obstacle1();
if(boat.isTouching(obstacleGroup)){
gameState=END;
  obstacleGroup.destroyEach();
  p2Group.destroyEach();
}
  
  if(keyDown("down")){
    boat.y=boat.y+3;
  }
   if(keyDown("up")){
    boat.y=boat.y-3;
  }
  }
  else if(gameState===END){
    sea.velocityX=0;
    restart.visible=true;
    gameover.visible=true;
    
        obstacleGroup.setVelocityXEach(0);
    p2Group.setVelocityXEach(0);
    //obstacleGroup.setLifetimeEach(-1);
    //p2Group.setLifetimeEach(-1);
    if(mousePressedOver(restart)) {
      reset();
    }
    score=0;
  }
  
drawSprites();
    
   text("Score: "+ score, 500,50);
  
  score = score + Math.round(getFrameRate()/60);
    text("points: "+ points, 440,50);
 

}

function obstacle1(){
  if (frameCount % 300 === 0) {
    var obstacle = createSprite(600,120,40,10);
    obstacle.y = Math.round(random(100,500));
    obstacle.addImage(sharkImg);
    obstacle.scale = 0.1;
    obstacle.velocityX = -3;
    obstacle.lifetime = 200;
    obstacleGroup.add(obstacle);
  }
}
function reset(){
  gameState = PLAY;
  gameover.visible = false;
  restart.visible = false;

  obstacleGroup.destroyEach();
  score = 0;
  points=0;
}
function p2(){
  if (frameCount % 223 === 0) {
    var obstacle1 = createSprite(600,120,40,10);
    obstacle1.y = Math.round(random(100,500));
    obstacle1.addImage(coinImg);
    obstacle1.scale = 0.1;
    obstacle1.velocityX = -3;
    obstacle1.lifetime = 200;
p2Group.add(obstacle1);
  }
}
